
public class Tran {
	/***********************************************************************
	class Tran - an object consisting of a number of shares and a price sold
				 at.
	***********************************************************************/
	public int _numShares;
	public int _price;
	
	public Tran(int numShares, int price)
	{
		// creates a Tran with numshares and price
		_numShares = numShares;
		_price = price;
	}
}
